import os
import sys
import glob
import argparse
from wrapper import bmSBT,bmSSBT,bmASSBT


def benchmarkSBT(args,srr_list,raw_fastqs_dir, re_prefix,query_seqs):

    root = "~/seqOthello/cmp_sbt/srr2652/"
    re_dir = re_prefix+str(args.max_filters)+"/"

    if args.run_query:
        for q in query_seqs:
            run = bmSBT.sbt(srr_list,raw_fastqs_dir,root,".fastq",
                thresholds=[args.theta],query=q,
                re_dir=re_dir,max_filters=args.max_filters)
            run.sbt_query()

def benchmarkSSBT(args,srr_list,raw_fastqs_dir, re_prefix,query_seqs):
    root = "~/seqOthello/cmp_ssbt/srr2652/"
    re_dir = re_prefix+str(args.max_filters)+"/"

    if args.run_query:
        for q in query_seqs:
            run = bmSSBT.ssbt(srr_list,raw_fastqs_dir,root,".fastq",
                thresholds=[args.theta],query=q,
                re_dir=re_dir,max_filters=args.max_filters)
            run.ssbt_query()

def benchmarkASSBT(args,srr_list,raw_fastqs_dir, re_prefix,query_seqs):
    root = "~/seqOthello/cmp_sbtas/srr2652/"
    re_dir = re_prefix+str(args.max_filters)+"/"

    if args.run_query:
        for q in query_seqs:
            run = bmASSBT.assbt(srr_list,raw_fastqs_dir,root,".fastq",
                thresholds=[args.theta],query=q,
                re_dir=re_dir,max_filters=args.max_filters)
            run.assbt_query()


parser = argparse.ArgumentParser()

group = parser.add_mutually_exclusive_group()
group.add_argument('--sbt',action='store_true')
group.add_argument('--ssbt',action='store_true')
group.add_argument('--sbtas',action='store_true')

query = parser.add_mutually_exclusive_group()
query.add_argument('--small_batch',action='store_true')
query.add_argument('--large_batch',action='store_true')

parser.add_argument('--theta', type=float, default=0.9,
    nargs='?',help='theta use for quary (0-1)')

parser.add_argument('--max_filters',default=1,nargs='?',
    help = 'The max-filters parameter in SBTs')

parser.add_argument('--run_query', action='store_true', help='bar help')



if __name__ == "__main__":
    args = parser.parse_args()
    raw_fastqs_dir = "~/data/srr2652/fq/"
    srrList = "~/data/srr_2652_list.txt"
    smallbatchQueryDir = '~/data/GenCodeV25_smallbatch/'

    query_seq = list()
    re_prefix = ''

    if args.small_batch:
        query_seq = glob.glob(os.path.join(smallbatchQueryDir,"rand1k*"))
        re_prefix = "small_batch_mf"

    if args.large_batch:
        query_seq = "~/data/gencode.v25.transcripts.fa"
        re_prefix = "large_batch_mf"


    if isinstance(query_seq,basestring):
        query_seq = [query_seq]

    assert len(query_seq)>0, "No query sequence found!"


    if args.sbt:
        benchmarkSBT(args,srrList,raw_fastqs_dir,re_prefix,query_seqs = query_seq)

    if args.ssbt:
        benchmarkSSBT(args,srrList,raw_fastqs_dir,re_prefix,query_seqs = query_seq)

    if args.sbtas:
        benchmarkASSBT(args,srrList,raw_fastqs_dir,re_prefix,query_seqs = query_seq)
