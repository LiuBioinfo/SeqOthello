import psutil
import time
import subprocess
class Benchmark(object):
	def __init__(self,cmd,fhandle=None):
		self.cmd = cmd
		# unit: GB
		self.max_memo=0
		# unit: Minute
		self.run_time=0
		self.fhandle=fhandle

	def pmemo_time(self):
		t0 = time.time()
		if self.fhandle is not None:
			p = subprocess.Popen(self.cmd,stdout=self.fhandle)
		else:
			p = subprocess.Popen(self.cmd)
		self.max_memo = self.get_peak_memo(p)
		#print "this is memeo: %.3f"%self.max_memo
		t1 = time.time()
		self.run_time = float(t1 - t0)/60.0

	def get_peak_memo(self,p):
		memo_list = []
		process = psutil.Process(p.pid)
		while p.poll() == None:
			memo_list.append(process.memory_full_info().rss)
			time.sleep(1)
		max_memo = max(memo_list)*1.0/1024/1024/1024
		return max_memo
