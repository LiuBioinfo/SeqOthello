import os
import sys
from benchmark import Benchmark
import time
import argparse
from collections import defaultdict
import subprocess
from time import gmtime, strftime

class sbt(object):
	def __init__(self,seq_list,seq_dir,out_dir,seq_type,
		thresholds=None,query=None,re_dir=None,max_filters=1):
		self.sbtbin = "~/apps/bloom_tree_git/bloomtree/src/bt"
		self.seq_list = seq_list
		self.seq_dir = seq_dir
		self.seq_type = seq_type
		self.out_dir = out_dir
		self.kmer_size = 20
		self.cutoff_log = cutoff_log
		self.bfbv_dir = out_dir+"bfbv/"
		self.bfbv_list = self.bfbv_dir+"bfbvlist.txt"
		self.sbtf = self.bfbv_dir + "sbt.txt"
		self.sbtcompressed = self.bfbv_dir + "sbtcompressed.txt"
		if re_dir is None:
			self.re_dir = out_dir+"results/"
		else:
			self.re_dir = out_dir+re_dir
		self.threads = 16
		self.hashfile = out_dir+"hashfile"	
		self.cutoff = defaultdict()
		self.make_dirs()
		self.init_hash()
		self.thresholds = thresholds
		self.query = query
		self.sbtbfbv_dir = sbtbfbv_dir
		self.max_filters = max_filters
		self.bench_log = open(self.re_dir+"benchmark.log",'a',2)
		timestr = time.strftime("%Y%m%d-%H%M%S")
		self.params = open(self.re_dir+timestr+"params.log",'w',2)
		self.params.write("# "+strftime("%Y-%m-%d %H:%M:%S\n", gmtime()))
		self.params.write("# SBT\n")
		self.params.write("# kmer_length =  %d\n"%self.kmer_size)
		self.params.write("# threads     =  1\n")
		self.params.write("# results_dir =  %s\n"%self.re_dir)
		self.params.write("# bfbv_dir    =  %s\n"%self.bfbv_dir)
		self.params.write("# query_seq   =  %s\n"%self.query)
		self.params.write("# max_filters =  %s\n"%self.max_filters)

	def make_dirs(self):
		[os.system("mkdir -p " + path) for path in [self.seq_dir,self.out_dir,self.bfbv_dir,self.re_dir]]

	def init_hash(self):
		os.chdir(self.out_dir)
		subprocess.call([self.sbtbin, "hashes", "--k", str(self.kmer_size), "hashfile", "1" ])

	def get_cutoff(self):
		cutoff_f = self.out_dir+"exp_cutoff.txt"
		with open(cutoff_f,'r') as finput:
			for line in finput:
				cols = line.strip().split()
				self.cutoff[cols[0]] = cols[1]

	def sbt_count(self):
		self.get_cutoff_from_log()
		bfbv_list = open(self.bfbv_list,'w')
		with open(self.seq_list,'r') as finput:
			t0 = time.time()
			for line in finput:
				sample = line.strip()
				cmd = [self.sbtbin,"count", "--cutoff",str(self.cutoff[sample]), 
					"--threads", str(self.threads),self.out_dir+"hashfile", 
					str(2000000000),
					"<(zcat",self.seq_dir+sample+self.seq_type,")",
					self.bfbv_dir+sample+".bf.bv"]
				subprocess.call(" ".join(cmd),shell=True,executable='/bin/bash')
				bfbv_list.write(sample+"\n")				
			t1 = time.time()
			self.bench_log.write("count\t%.3f\n"%(float(t1-t0)/60.0))

	def sbt_sbuild(self):
		os.chdir(self.bfbv_dir)
		cmd = [self.sbtbin, "build",self.hashfile,
					self.bfbv_list,
					"sbt.txt"]
		bc = Benchmark(cmd)
		bc.pmemo_time()
		self.bench_log.write("sbuild\t%.3f\t%.3f\n"%(bc.max_memo,bc.run_time))

	def sbt_compress(self):
		os.chdir(self.bfbv_dir)
		cmd = [self.sbtbin, "compress",self.sbtf,self.sbtcompressed]
		bc = Benchmark(cmd)
		bc.pmemo_time()
		self.bench_log.write("build_compressed\t%.3f\t%.3f\n"%(bc.max_memo,bc.run_time))
	def sbt_query(self):
		os.chdir(self.bfbv_dir)
		for t in self.thresholds:
			re = self.re_dir+"t_"+str(t)+".txt"	
			cmd = [self.sbtbin, "query","--max-filters", str(self.max_filters),"-t", str(t), self.sbtcompressed, self.query, re]
			bc = Benchmark(cmd)
			bc.pmemo_time()
			self.bench_log.write("query\t%s\t%.3f\t%.3f\n"%(str(t),bc.max_memo,bc.run_time))
			
def sbt_human_srr_build():
	root = os.getcwd()+'/'
	seqdir =  "/scratch/lji226/projects/xal_seq/fq/"
	flist = root+"srr_2652_list.txt"
	outdir = root
	run = sbt(flist,seqdir,outdir,".fastq")
	run.sbt_count()
	run.sbt_sbuild()
	run.sbt_compress()

if __name__ == "__main__":
	sbt_human_srr_build()
