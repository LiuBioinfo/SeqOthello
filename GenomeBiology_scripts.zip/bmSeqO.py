import os
import sys
from benchmark import Benchmark
import time
from collections import defaultdict
import subprocess

from time import gmtime, strftime

"""
@TODO:
	Add checks for existed kmer, bitmap
"""

class seqoth(object):
	def __init__(self,seq_list,seq_dir,out_dir,seq_type,
		code_path,kmer_size,infobitsize,
		jf_path,
		key_list,
		query,
		make=True,kmer_dir=None,bm_dir=None,map_dir=None,cutoff_file=None):

		self.seq_list = seq_list
		self.seq_dir = seq_dir
		self.seq_type = seq_type
		self.out_dir = out_dir+'/'
		self.infobitsize = str(infobitsize)
		self.key_list = key_list
		if kmer_dir is None:
			self.kmer_dir = self.out_dir+"kmers/"
		else:
			self.kmer_dir = kmer_dir
		if bm_dir is None:
			#self.bm_dir = self.out_dir+"bitmap_"+self.infobitsize+"/"
			self.bm_dir = self.out_dir+"bitmap/"
		else:
			self.bm_dir = bm_dir
		self.bm_list_dir = self.bm_dir+"/list/"
		self.bm_list = []
		if map_dir is None:
			#self.map_dir = self.bm_dir+"map_"+self.infobitsize+"/"
			self.map_dir = self.bm_dir+"map/"
		else:
			self.map_dir = map_dir
		self.map_file = self.map_dir+"map"
		self.re_dir = self.out_dir+"results/"
		self.expr_level = self.bm_dir + "expr_level.txt"
		self.grp_dir = os.path.join(self.map_dir,"grp/")
		self.grp_list = os.path.join(self.grp_dir,"grp.list.txt")
		self.make_dirs()
		self.threads = 16

		self.cutoff = defaultdict()
		if cutoff_file is not None:
			self.parse_cutoff_file(cutoff_file)
		else:
			self.get_cutoff()

		# not needed in the the new implementation
		# self.seq_count = self.get_seq_count()
		self.bins = self.make_exec(code_path,make=make)
		self.bins["jellyfish"] = jf_path
		self.bench_log = open(self.re_dir+"benchmark.log",'a',2)

		self.query = query
		self.kmer_size = kmer_size
		self.bench_log.write("#==========================================#\n")
		self.bench_log.write("# "+strftime("%Y-%m-%d %H:%M:%S\n", gmtime()))
		self.bench_log.write("# seqOthello test setting\n")

		self.bench_log.write("# kmer_len =  %d\n"%self.kmer_size)
		# self.bench_log.write("# total_samples (8)= %d\n"%self.seq_count)
		self.bench_log.write("# infobit = %s\n"%self.infobitsize)
		self.bench_log.write("# bitmaps = %s\n"%self.bm_dir)
		self.bench_log.write("# map = %s\n"%self.map_dir)


	def make_dirs(self):
		[os.system("mkdir -p " + path) for path in [self.seq_dir,self.out_dir,self.kmer_dir,self.bm_dir,self.map_dir,self.re_dir,self.bm_list_dir,self.grp_dir]]

	def get_seq_count(self):
		# make sure the seq_count is the multiplication of 8
		with open(self.seq_list) as finput:
			scount = 0
			for line in finput:
				if "SRR" in line.strip() or 'longest_transcripts':
					scount += 1
			if scount == 0:
				print "No sequence id in the file, exit!"
				sys.exit(-1)
			if scount % 8 != 0:
				scount = (scount / 8 + 1)*8
			return scount

	def parse_cutoff_file(self,cutoff_file):
		with open(cutoff_file,'r') as fstream:
			for line in fstream:
				sample = line.strip().split()
				self.cutoff[sample[0]] = int(sample[2])

	def get_cutoff(self):
		# Need to modify for fastq.gz file
		ofile = open(self.out_dir+"size_and_cutoff.txt",'w')

		with open(self.seq_list,'r') as finput:
			for line in finput:
				sample = line.strip()
				if sample == "longest_transcripts":
					self.cutoff[sample] = 1
					ofile.write("%s\t%.3f\t%d\n"%(sample,0,self.cutoff[sample]))
					continue
				size = os.path.getsize(self.seq_dir+sample+self.seq_type)
				size = size/1024.0/1024.0/2
				if size <= 300:
					self.cutoff[sample] = 1
				elif size > 300 and size <= 500:
					self.cutoff[sample] =  3
				elif size > 500 and size <= 1000:
					self.cutoff[sample] = 10
				elif size > 1000 and size <= 3000:
					self.cutoff[sample] = 20
				else:
					self.cutoff[sample] = 50
				ofile.write("%s\t%.3f\t%d\n"%(sample,size,self.cutoff[sample]))
		ofile.close()



	def make_exec(self,codePath, make=False):

		workingDir = self.out_dir
		if make:
			cwd = os.getcwd()
			os.chdir(codePath)
			print "Compiling source code..."
			os.system("bash buildUKYDLX.sh" + " > " + workingDir +"compile_src.log 2>&1")
			os.chdir(cwd)

		execs = defaultdict()
		# EXPRESSION
		#execs['kmer2bin_expr'] = "SortToBinaryWith16Binfo"
		#infobitsize = 2 if self.infobitsize not in [2,3,4] else self.infobitsize
		#execs['buildmap_expr'] = "BuilderExp"+str(COUNT)+".EXP"+str(infobitsize)
		# OCCURRENCE
		execs['kmer2bin_occr'] = "PreProcess"
		execs['bin2grp'] = "Group"  
		execs['buildmap_occr'] = "Build"
		execs["query_occr"] = "Query"
		codePath = os.path.join(codePath,"build/bin/")
		execs = {f: os.path.join(codePath, execs[f]) for f in execs}
		print execs
		if all(os.path.isfile(execs[f]) for f in execs):
			return execs
		else:
			print execs
			return None

	def seqO_2kmer(self):
		# Extract kmer using jellyfish and then
		# convert it to bitmap
		
		with open(self.seq_list,'r') as finput:
			print "Started jellyfish..."
			t0 = time.time()
			for line in finput:
				sample = line.strip()

				cmd = [self.bins['jellyfish'],"count", 
						"-m", str(self.kmer_size), "-s 1000M",
						"-C", "-t", str(self.threads), 
						"-o", self.kmer_dir+sample+".jf",
						"<(zcat",self.seq_dir+sample+self.seq_type,")"]
				print " ".join(cmd)
				subprocess.call(" ".join(cmd),shell=True,executable='/bin/bash')
				cmd = [self.bins['jellyfish'],"dump", 
						"-t",
						"-L",str(self.cutoff[sample]),
						"-c", self.kmer_dir+sample+".jf",
						"-o", self.kmer_dir+sample+".kmer"]
				print " ".join(cmd)
				subprocess.call(cmd)
				#subprocess.call(["rm", self.kmer_dir+sample+".jf"])
			t1 = time.time()
			print "Finished converting fq to kmer..."
			self.bench_log.write("jellyfish\t%.3f\n"%(float(t1-t0)/60.0))

	def seqO_kmer2bin_expr(self):
		bm_list = open(self.bm_list,'w')
		kmer2bin_log = self.bm_dir+"kmer2bin_log/"
		os.system("mkdir -p "+kmer2bin_log)
		with open(self.seq_list,'r') as finput:
			print "Started kmer2bitmap..."
			t0 = time.time()
			for line in finput:
				sample = line.strip()
				fhandle = open(kmer2bin_log+sample+".expr",'w')
				cmd = [self.bins['kmer2bin_expr'],
						self.kmer_dir+sample+".kmer",
						self.bm_dir+sample+".bin",
						str(self.kmer_size),self.infobitsize,
						str(self.cutoff[sample])]
				print " ".join(cmd)
				subprocess.call(cmd,stdout = fhandle)
				fhandle.close()
				bm_list.write(sample+".bin\n")
			t1 = time.time()
			print "Finished converting kmer to bitmap..."
			self.bench_log.write("seqOthello\tbitmap\t%.3f\n"%(float(t1-t0)/60.0))
		# parse the expr to get the expr_level.txt file
		ofile = open(self.expr_level,'w')
		with open(self.seq_list,'r') as finput:
			for line in finput:
				sample = line.strip()
				tmp = self.parse_expr(kmer2bin_log+sample+".expr")
				print tmp
				ofile.write(tmp)
		ofile.close()



	def kmer2bin(self):
		bm_list_invalid = open(self.bm_list_dir+"/INVALID.txt", 'w')
		kmer2bin_log = self.bm_dir+"kmer2bin_log/"
		os.system("mkdir -p "+kmer2bin_log)
		with open(self.seq_list,'r') as finput:
			print "Started kmer2bin..."
			t0 = time.time()
			count = 0
			index = 0
			for line in finput:
				if count%50== 0:
					bm_list = open(self.bm_list_dir+"/"+str(index)+".txt",'w')
					self.bm_list.append(self.bm_list_dir+"/"+str(index)+".txt")
					index += 1

				sample = line.strip()
				# first check if kmer file exists or kmer file is zero
				try:
					stats = os.stat(self.kmer_dir+sample+".kmer").st_size
					if stats == 0:
						print "Skip sample %s"%sample
						bm_list_invalid.write(sample)
						bm_list_invalid.write("\n")
						continue
				except OSError:
					print "SAMPLE %s kmer file not exists!" %sample
					continue
				fhandle = open(kmer2bin_log+sample+".occr",'w')
				cmd = [self.bins['kmer2bin_occr'],
						"--in="+self.kmer_dir+sample+".kmer",
						"--out="+self.bm_dir+sample+".bin",
						'--k='+str(self.kmer_size)
						]
				print  >> sys.stderr," ".join(cmd)
				subprocess.call(cmd,stdout = fhandle)
				fhandle.close()
				bm_list.write(sample+".bin\n")
				count += 1
			t1 = time.time()
			print "Finished converting kmer to bin..."
			self.bench_log.write("seqOthello\tkmer2bin\t%.3f\n"%(float(t1-t0)/60.0))


	def seqO_kmer2bin_occr(self):
		bm_list = open(self.bm_list,'w')
		bm_list_invalid = open(self.bm_list+"INVALID", 'w')
		kmer2bin_log = self.bm_dir+"kmer2bin_log/"
		os.system("mkdir -p "+kmer2bin_log)
		with open(self.seq_list,'r') as finput:
			print "Started kmer2bitmap..."
			t0 = time.time()
			for line in finput:
				sample = line.strip()
				# first check if kmer file exists or kmer file is zero
				try:
					stats = os.stat(self.kmer_dir+sample+".kmer").st_size
					if stats == 0:
						print "Skip sample %s"%sample
						bm_list_invalid.write(sample)
						bm_list_invalid.write("\n")
						continue
				except OSError:
					print "SAMPLE %s kmer file not exists!" %sample
					continue
				fhandle = open(kmer2bin_log+sample+".occr",'w')
				cmd = [self.bins['kmer2bin_occr'],
						self.kmer_dir+sample+".kmer",
						self.bm_dir+sample+".bin",
						str(self.kmer_size),
						str(self.cutoff[sample])]
				print  >> sys.stderr, " ".join(cmd)
				subprocess.call(cmd,stdout = fhandle)
				fhandle.close()
				bm_list.write(sample+".bin\n")
			t1 = time.time()
			print "Finished converting kmer to bitmap..."
			self.bench_log.write("seqOthello\tbitmap\t%.3f\n"%(float(t1-t0)/60.0))

	def seqO_bin2grp(self):
		bDir = self.bm_dir
		bList = self.bm_list

		grp_list = open(self.grp_list,'w')
		count = 0
		t0 = time.time()
		for l in self.bm_list:
			cmd = [self.bins['bin2grp'], 
					"--flist="+l, 
					"--folder="+bDir,
					"--output="+self.grp_dir+str(count)+".grp"
					]
			print  >> sys.stderr, " ".join(cmd)
			subprocess.call(cmd)
			grp_list.write(str(count)+".grp\n")
			count+=1
		t1 = time.time()
		self.bench_log.write("seqOthello\tbins2grp\t%.3f\n"%(float(t1-t0)/60.0))
		 

	def parse_expr(self,expr_f):
		with open(expr_f,'r') as finput:
			lc = 0
			for line in finput:
				if lc == 3:
					return line
				lc += 1

	def buildmap_expr(self,expLevel="R",force=True):
		"""
		Usage:
			1. binary file lists contains the names of the files converted by kmer2bin
			2. diretory for the binary files
			3. kmer length with prefix("-")
			4. file name for the output map file
			5. working direcoty
			6. KmerType: [R/C/U/H] for Raw/Compressed/Universial/Hybrid)
			7. ExpressionLevelOption: R, us the expression levels in the kmer file
			8. optional: kmer list filter
		"""
		bDir = self.bm_dir
		bList = self.bm_list
		try:
			stats = os.stat(bList).st_size
			if stats == 0:
				print "bitmap list is empty!"
				sys.exit(-1)
		except OSError:
			sys.exit(-1)
		tmp_dir = os.path.join(self.map_dir,"tmp/")
		map_file = self.map_file
		os.system("mkdir -p "+tmp_dir)
		kmerLen = self.kmer_size

		if not os.path.isfile(map_file) or force:
			cmd = [self.bins['buildmap_expr'], bList, 
								bDir,
								'-'+str(kmerLen), 
								map_file,
								tmp_dir,
								"R",
								expLevel,
								self.key_list]
			print  >> sys.stderr, " ".join(cmd)
			bc = Benchmark(cmd)
			bc.pmemo_time()

			self.bench_log.write("seqOthello\tbuildmap\t%.3f\t%.3f\n"%(bc.max_memo,bc.run_time))

	def buildmap_occr(self,force=True):
		"""
		"""
		bDir = self.grp_dir
		bList = self.grp_list
		try:
			stats = os.stat(bList).st_size
			if stats == 0:
				print "bitmap list is empty!"
				sys.exit(-1)
		except OSError:
			sys.exit(-1)
		map_file = self.map_file

		if not os.path.isfile(map_file) or force:
			cmd = [self.bins['buildmap_occr'], 
					"--flist="+bList, 
					"--folder="+bDir,
					"--out-folder="+self.map_dir]
			print  >> sys.stderr, " ".join(cmd)
			bc = Benchmark(cmd)
			bc.pmemo_time()

			self.bench_log.write("seqOthello\tbuildmap\t%.3f\t%.3f\n"%(bc.max_memo,bc.run_time))

	def run_query_expr(self,ShowExpLevel="N"):
		nodeIsCompressed="N"
		UseBatchQuery="Y"
		DetailedMap="N"
		res_dir=self.re_dir
		if ShowExpLevel == "O":
			res_file=os.path.join(res_dir,"expression.txt")
		else:
			res_file=os.path.join(res_dir,"occurrence.txt")
		ExpressionLevel = self.expr_level
		if not os.path.isfile(ExpressionLevel):
			print "Expression file not exist!"
			sys.exit(-1)
		rehandle = open(res_file,'w')
		cmd = [self.bins["query_expr"],self.map_file,self.query,str(self.kmer_size),
				nodeIsCompressed,UseBatchQuery,DetailedMap,str(self.infobitsize),ShowExpLevel,
				ExpressionLevel]
		print " ".join(cmd)
		bc = Benchmark(cmd,rehandle)
		bc.pmemo_time()
		rehandle.close()
		self.bench_log.write("seqOthello\tquery\t%.3f\t%.3f\n"%(bc.max_memo,bc.run_time))

	def run_query_occr(self,threads=1):
		"""
		-h, --help                        Display this help menu
		--map-folder=[string]             the path contains SeqOthello mapping
		                                file.
		--transcript=[string]             file containing transcripts
		--output=[string]                 where to put the results
		--detail                          Show the detailed query results for the
		                                transcripts
		--noreverse                       do not use reverse complement
		--qthread=[int]                   how many threads to use for query,
		                                default = 1

		"""

		res_dir=self.re_dir
		res_file=os.path.join(res_dir,"occurrence.txt")
		rehandle = open(os.path.join(res_dir,"occurrence.log"),'w')
		cmd = [self.bins["query_occr"],
			"--map-folder="+self.map_dir,
			"--transcript="+self.query,
			"--output="+res_file,
			"--qthread="+str(threads)
			]
		print " >> sys.stderr", " ".join(cmd)
		bc = Benchmark(cmd,rehandle)
		bc.pmemo_time()
		rehandle.close()
		self.bench_log.write("seqOthello\tquery\t%.3f\t%.3f\n"%(bc.max_memo,bc.run_time))

def build_expression():
	outdir = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200/"
	flist = "/scratch/lji226/projects/xal_seq/check_human/data/sample_200.list.txt"
	#flist="/scratch/lji226/projects/xal_seq/jpl_results/SBT-AS/test1/human_srr/sample200/testfq.txt"
	seqdir =  "/scratch/lji226/projects/xal_seq/fq/"
	query =  "/scratch/lji226/projects/xal_seq/check_human/data/queries.longest_transcripts_per_gene.fa"
	#query = "/scratch/lji226/projects/xal_seq/jpl_results/SBT-AS/test1/human_srr/sample200/"+"t_0.7.txt"
	keylist="/scratch/lji226/projects/xal_seq/kmer/info/keylist"
	src="/home/lji226/git/seqOthello_paper/codes/seqQueryTree/build/SeqOthello/"

	sample200 = seqoth(flist,seqdir,outdir,".fastq",src,20,2,"jellyfish",keylist,query,make=True)
	sample200.seqO_2kmer()
	sample200.seqO_kmer2bin()
	sample200.buildmap()
	sample200.run_query()

def build_occurrence(mode="debug"):
	#src = '/home/lji226/git/seqOthello_paper/codes/seqQueryTree/build/SeqOthello/'
	src = "/home/lji226/git/seqOthello_paper/codes/seqothello/"
	flist = "/scratch/lji226/projects/xal_seq/check_human/data/sample_200.list.txt"
	seqdir =  "/scratch/lji226/projects/xal_seq/fq/"
	query =  "/scratch/lji226/projects/xal_seq/check_human/data/queries.longest_transcripts_per_gene.fa"
	keylist="/scratch/lji226/projects/xal_seq/kmer/info/keylist"
	if mode == "debug":
		outdir = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200/debug/empty_kmer/"
		#flist="/scratch/lji226/projects/xal_seq/jpl_results/SBT-AS/test1/human_srr/sample200/testfq.txt"
		flist="/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200/debug/fq2kmer_empty_sample.txt"
		query = "/scratch/lji226/projects/xal_seq/jpl_results/SBT-AS/test1/human_srr/sample200/"+"t_0.7.txt"

		sample200 = seqoth(flist,seqdir,outdir,".fastq",src,20,1,"jellyfish",keylist,query,make=False)
		#sample200.seqO_2kmer()
		sample200.seqO_kmer2bin_occr()
		sample200.buildmap_occr()
		sample200.run_query_occr()
	if mode=="sample200":
		outdir = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200_newCode_190k/"
		query = "/scratch/lji226/projects/xal_seq/jpl_results/gencode.v25.transcripts.fa"
		sample200 = seqoth(flist,seqdir,outdir,".fastq",src,20,1,"jellyfish",keylist,query,make=False,bm_dir="/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200/bitmap_1/")#,kmer_dir="/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/kmer/")
		#sample200.seqO_2kmer()
		#sample200.seqO_kmer2bin_occr()
		#sample200.buildmap_occr()
		sample200.run_query_occr()
	if mode=="sample201":
		outdir = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200_w30kT/"
		flist="/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200_w30kT/sample_201.list.txt"
		kmer_dir="/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/kmer/"
		keylist="/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200_w30kT/kmer200_w_ltranscripts.keylist"
		query = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/sample200_w30kT/query/ENSG00000182944.transcripts.seq"
		sample200 = seqoth(flist,seqdir,outdir,".fastq",src,20,1,"jellyfish",keylist,query,make=False,kmer_dir=kmer_dir)
		
		#sample200.seqO_kmer2bin_occr()
		#sample200.buildmap_occr()
		sample200.run_query_occr()
	if mode=="all":
		outdir = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/ALL_V25_newcode/"
		bmdir = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/occurrence/bitmap_1/"
		flist = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/srr_2652_list.txt"
		#query = "/scratch/lji226/projects/xal_seq/jpl_results/gencode.v19.pc_lncRNA_transcripts.fa.seq"
		query = "/scratch/lji226/projects/xal_seq/jpl_results/gencode.v25.transcripts.fa"
		kmer_dir = "/scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/kmer/"
		alls = seqoth(flist,seqdir,outdir,".fastq",src,20,1,"jellyfish",keylist,query,make=True,kmer_dir=kmer_dir,bm_dir=bmdir)
		#alls.seqO_2kmer()
		#alls.seqO_kmer2bin_occr()
		#alls.buildmap_occr()
		alls.run_query_occr()
#/home/lji226/git/seqOthello_paper/codes/wrapper/seqothello/bmSeqO.py


#build_occurrence(sys.argv[1])
