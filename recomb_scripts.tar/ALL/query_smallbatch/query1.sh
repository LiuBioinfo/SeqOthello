#!/bin/bash
#SBATCH -n 12
#SBATCH -t 1:01:00
#SBATCH -p Long
#SBATCH -o /scratch/yyu233/Sept/logs/QuerySam2652.Thr1.TransAll.log

cd /scratch/yyu233/Sept/

python /scratch/yyu233/Sept/runmeasure.py --cmd '/home/yyu233/seq/build/bin/Query --map-folder=/scratch/yyu233/Sept/mapout2652/ --transcript=/scratch/yyu233/Sept/longestTransSamp1K/longest.rand1k.samp1 --output=/scratch/yyu233/Sept/query2652.sampletrans1 --qthread=1 --lthread=16' --log querylogs/Querylog.Sam2652.Thr1.Transsample1 2>querylogs/Timelog.Sam2652.Thr1.Transsample1

