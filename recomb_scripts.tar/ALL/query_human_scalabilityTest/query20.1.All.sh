#!/bin/bash
#SBATCH -n 12
#SBATCH -t 1:01:00
#SBATCH -p Long
#SBATCH -o /scratch/yyu233/Sept/logs/QuerySam1000.Thr1.TransAll.log

cd /scratch/yyu233/Sept/
echo 1000
echo 20
echo /scratch/yyu233/Sept/gencode.All.fa

python /scratch/yyu233/Sept/runmeasure.py --cmd '/home/yyu233/seq/build/bin/Query --map-folder=/scratch/yyu233/Sept/mapout1000/ --transcript=/scratch/yyu233/Sept/gencode.All.fa --output=/scratch/yyu233/Sept/queryout1000.1 --qthread=1' --log querylogs/Querylog.Sam1000.Thr1.TransAll 2>querylogs/Timelog.Sam1000.Thr1.TransAll

