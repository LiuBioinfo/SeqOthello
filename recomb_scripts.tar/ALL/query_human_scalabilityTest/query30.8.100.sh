#!/bin/bash
#SBATCH -n 12
#SBATCH -t 1:01:00
#SBATCH -p Long
#SBATCH -o /scratch/yyu233/Sept/logs/QuerySam1500.Thr8.Trans100.log

cd /scratch/yyu233/Sept/
echo 1500
echo 30
echo /scratch/yyu233/Sept/gencode.100.fa

python /scratch/yyu233/Sept/runmeasure.py --cmd '/home/yyu233/seq/build/bin/Query --map-folder=/scratch/yyu233/Sept/mapout1500/ --transcript=/scratch/yyu233/Sept/gencode.100.fa --output=/scratch/yyu233/Sept/queryout1500.8 --qthread=8' --log querylogs/Querylog.Sam1500.Thr8.Trans100 2>querylogs/Timelog.Sam1500.Thr8.Trans100

