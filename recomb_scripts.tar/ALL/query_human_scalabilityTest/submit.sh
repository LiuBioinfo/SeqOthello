#!/bin/bash
module load Python
#for THR in 1 2 4 8 16 
#for SAM in 200 500 1000 1500 2000 2652; do 
for THR in 1 2 4 6 8; do
for SAM in 50 100 200 300 400 500 750 1000 1500 2000 2652; do 
for TRANSCOUNT in 100 1k 10k All; do 
    GRP=$((SAM / 50 ))
    echo $SAM , $GRP
    TRANS='\/scratch\/yyu233\/Sept\/gencode.'$TRANSCOUNT'.fa'
    sed -e 's/SAMPLECNT/'$SAM'/g' query.shtemplate | sed -e 's/GROUPCNT/'$GRP'/g' | sed 's/THREADCNT/'$THR'/g' | sed 's/TRANSCRIPT/'$TRANS'/g' | sed 's/TRANSCOUNT/'$TRANSCOUNT'/g'> query${GRP}.${THR}.${TRANSCOUNT}.sh
    sbatch query${GRP}.${THR}.${TRANSCOUNT}.sh
done
done
done


