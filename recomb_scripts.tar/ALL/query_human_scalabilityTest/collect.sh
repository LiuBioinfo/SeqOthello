#!/bin/bash
module load Python
for THR in 1 2 4 6 8; do
for SAM in 50 100 200 300 400 500 750 1000 1500 2000 2652; do 
for TRANSCOUNT in 100 1k 10k All; do 
    GRP=$((SAM / 50 ))
    echo `echo SAMPLECNOUT=$SAM THREAD=$THR TRANS=$TRANSCOUNT` \
    `python checklog.py < /scratch/yyu233/Sept/querylogs/Timelog.Sam${SAM}.Thr$THR.Trans${TRANSCOUNT}` 
done
done
done

