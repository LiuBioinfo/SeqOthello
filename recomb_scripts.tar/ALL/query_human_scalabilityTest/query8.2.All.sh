#!/bin/bash
#SBATCH -n 12
#SBATCH -t 1:01:00
#SBATCH -p Long
#SBATCH -o /scratch/yyu233/Sept/logs/QuerySam400.Thr2.TransAll.log

cd /scratch/yyu233/Sept/
echo 400
echo 8
echo /scratch/yyu233/Sept/gencode.All.fa

python /scratch/yyu233/Sept/runmeasure.py --cmd '/home/yyu233/seq/build/bin/Query --map-folder=/scratch/yyu233/Sept/mapout400/ --transcript=/scratch/yyu233/Sept/gencode.All.fa --output=/scratch/yyu233/Sept/queryout400.2 --qthread=2' --log querylogs/Querylog.Sam400.Thr2.TransAll 2>querylogs/Timelog.Sam400.Thr2.TransAll

