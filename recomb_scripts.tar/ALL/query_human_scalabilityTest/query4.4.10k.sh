#!/bin/bash
#SBATCH -n 12
#SBATCH -t 1:01:00
#SBATCH -p Long
#SBATCH -o /scratch/yyu233/Sept/logs/QuerySam200.Thr4.Trans10k.log

cd /scratch/yyu233/Sept/
echo 200
echo 4
echo /scratch/yyu233/Sept/gencode.10k.fa

python /scratch/yyu233/Sept/runmeasure.py --cmd '/home/yyu233/seq/build/bin/Query --map-folder=/scratch/yyu233/Sept/mapout200/ --transcript=/scratch/yyu233/Sept/gencode.10k.fa --output=/scratch/yyu233/Sept/queryout200.4 --qthread=4' --log querylogs/Querylog.Sam200.Thr4.Trans10k 2>querylogs/Timelog.Sam200.Thr4.Trans10k

