#!/bin/bash
#SBATCH -n 12
#SBATCH -t 10:01:00
#SBATCH -p Long
#SBATCH -o /scratch/yyu233/Sept/logs/Build200.log

cd /scratch/yyu233/Sept/
rm -rf mapout200
mkdir mapout200
module load gcc/4.9.1
module load Python/2.7.8
module add Python/2.7.8
echo 200
echo 4
head -n 4 /scratch/yyu233/Sept/grp/grplist  | cut -d '/' -f6 > /scratch/yyu233/Sept/grp/grplist_4
which time
python /scratch/yyu233/Sept/runmeasure.py --cmd '/home/yyu233/seq/build/bin/Build --flist=/scratch/yyu233/Sept/grp/grplist_4 --folder=/scratch/yyu233/Sept/grp/ --out-folder=/scratch/yyu233/Sept/mapout200/' --log logs/Buildlog.SampleCNT200 2>logs/Timelog.SampleCNT200
#/usr/bin/time --verbose stdbuf -o 0 /home/yyu233/seq/build/bin/Build \
#        --flist=/scratch/yyu233/Sept/grp/grplistfile  \
#        --folder=/scratch/yyu233/Sept/grp/ \
#        --out-folder=/scratch/yyu233/Sept/mapout${SAMPLE_CNT}/ \
#        > logs/BuildLog.SampleCNT${SAMPLE_CNT} \
#        2> logs/Timelog.Build.SampleCNT${SAMPLE_CNT}

