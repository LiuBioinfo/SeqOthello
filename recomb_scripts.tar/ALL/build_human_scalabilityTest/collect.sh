#!/bin/bash
module load Python
for SAM in 50 100 200 300 400 500 750 1000 1500 2000 2652; do 
    GRP=$((SAM / 50 ))
    echo `echo SAMPLECNOUT=$SAM` \
    `python checklog.py < /scratch/yyu233/Sept/logs/Timelog.SampleCNT${SAM}` \
    `echo keycnt` \
    `grep 'KeyCount' /scratch/yyu233/Sept/mapout${SAM}/map.xml | cut -d'"' -f4  | awk '{s+=$1} END {print s}'` \
    `echo fsize` \
    `du  /scratch/yyu233/Sept/mapout${SAM}`
done

