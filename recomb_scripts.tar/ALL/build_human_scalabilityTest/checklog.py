
import fileinput
import time
lines = [line.rstrip('\n') for line in fileinput.input()]
ftr = [3600,60,1]
sel = [x[2:].split() for x in lines[4:-2] if len(x) >1]
#times = [time.strptime(x[0], "%H:%M:%S") for x in sel]
times = [sum([a*b for a,b in zip(ftr, map(int,x[0].split(':')))]) for x in sel]

mems = [int(x[2]) for x in sel]
diff = times[-1] - times[0]
print('total time {} s'.format(diff))
print('max memory {} kb'.format(max(mems)))
