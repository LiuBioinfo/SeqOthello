#!/bin/bash
#SBATCH -n 12
#SBATCH -t 10:01:00
#SBATCH -p Long
#SBATCH -o /scratch/yyu233/Sept/logs/Build100.log

cd /scratch/yyu233/Sept/
rm -rf mapout100
mkdir mapout100
module load gcc/4.9.1
module load Python/2.7.8
module add Python/2.7.8
echo 100
echo 2
head -n 2 /scratch/yyu233/Sept/grp/grplist  | cut -d '/' -f6 > /scratch/yyu233/Sept/grp/grplist_2
which time
python /scratch/yyu233/Sept/runmeasure.py --cmd '/home/yyu233/seq/build/bin/Build --flist=/scratch/yyu233/Sept/grp/grplist_2 --folder=/scratch/yyu233/Sept/grp/ --out-folder=/scratch/yyu233/Sept/mapout100/' --log logs/Buildlog.SampleCNT100 2>logs/Timelog.SampleCNT100
#/usr/bin/time --verbose stdbuf -o 0 /home/yyu233/seq/build/bin/Build \
#        --flist=/scratch/yyu233/Sept/grp/grplistfile  \
#        --folder=/scratch/yyu233/Sept/grp/ \
#        --out-folder=/scratch/yyu233/Sept/mapout${SAMPLE_CNT}/ \
#        > logs/BuildLog.SampleCNT${SAMPLE_CNT} \
#        2> logs/Timelog.Build.SampleCNT${SAMPLE_CNT}

