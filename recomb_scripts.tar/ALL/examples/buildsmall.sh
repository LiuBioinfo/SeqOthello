cd /scratch/yyu233/Sept/
mkdir mapoutsmall/
date > dateBeforeBuild
module load gcc/4.9.1
head -n 10 /scratch/yyu233/Sept/grp/grplist  | cut -d '/' -f6 > /scratch/yyu233/Sept/grp/grplistsmall
stdbuf -o 0 /home/yyu233/seq/build/bin/Build --flist=/scratch/yyu233/Sept/grp/grplistsmall --folder=/scratch/yyu233/Sept/grp/ --out-folder=/scratch/yyu233/Sept/mapoutsmall/ | tee Buildlog
date > dateAfterBuild
