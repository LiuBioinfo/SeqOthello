cd /scratch/yyu233/Sept/
mkdir mapout/
date > dateBeforeBuild
module load gcc/4.9.1
more /scratch/yyu233/Sept/grp/grplist  | cut -d '/' -f6 > /scratch/yyu233/Sept/grp/grplistfile
stdbuf -o 0 /home/yyu233/seq/build/bin/Build --flist=/scratch/yyu233/Sept/grp/grplistfile --folder=/scratch/yyu233/Sept/grp/ --out-folder=/scratch/yyu233/Sept/mapout/ | tee Buildlog
date > dateAfterBuild
