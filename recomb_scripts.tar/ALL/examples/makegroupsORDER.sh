#!/bin/bash
split /scratch/lji226/projects/xal_seq/jpl_results/seqO/test1/human_srr/srr_2652_list.txt -l 50
for k in 0 1 2 3 4 5 6 7 8 9 0; do
for i in `ls grporder.?${k}`; do
   /home/yyu233/seq/build/bin/Group --flist=$i --folder='/scratch/yyu233/Sept/bin/' --output=/scratch/yyu233/Sept/ordergrp/$i.grp
done &
done


