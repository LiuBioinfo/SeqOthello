#!/bin/bash
## Script to convert kmer files to binary files.
## usage: 
##        1. create a flist file that contains all the filenames of kmer files. (filename only)
##            ls *.kmer > flist
##            ./convertbinary.sh flist [folder that contains kmers] [folder to put binary files]
##            ./convertbinary.sh flist /scratch/lji226/projects/xal_seq/jpl_results/kmers/srr2653/k20_sbtpaper/ /scratch/yyu233/Sept/bin/

FOLDER=$2
OUT=$3
for f in `more $1`; do
    ./PreProcess --in=${FOLDER}$f --out=${OUT}$f.bin --k=20 
done

